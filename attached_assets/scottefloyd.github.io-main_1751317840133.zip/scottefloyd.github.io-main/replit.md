# Portfolio Website

## Overview

This is a full-stack portfolio website for Scott Floyd, a UX/UI Designer with a background in QA automation. The application features a modern, responsive design with a React frontend and Express backend, showcasing professional work, skills, and providing contact functionality.

## System Architecture

The application follows a full-stack TypeScript architecture with clear separation between client and server code:

- **Frontend**: React 18 with TypeScript, built using Vite
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but can be extended)
- **UI Framework**: shadcn/ui components with Tailwind CSS
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Build System**: Vite for frontend, esbuild for backend

## Key Components

### Frontend Architecture
- **Component Structure**: Modular React components organized by feature (hero, about, projects, skills, testimonials, contact)
- **UI Components**: shadcn/ui component library providing consistent design system
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Animations**: Framer Motion for smooth interactions and scroll animations
- **Forms**: React Hook Form with Zod validation
- **Icons**: Lucide React and React Icons

### Backend Architecture
- **API Layer**: RESTful endpoints for contact form submission and message retrieval
- **Storage Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **Middleware**: Request logging and error handling
- **Development**: Vite integration for hot reloading in development

### Database Schema
- **Users Table**: Basic user authentication structure (id, username, password)
- **Contact Messages Table**: Stores form submissions (id, firstName, lastName, email, subject, message, createdAt)
- **ORM**: Drizzle with PostgreSQL dialect for type-safe database operations

## Data Flow

1. **Client Requests**: Frontend makes API calls using TanStack Query
2. **API Processing**: Express routes handle requests with validation
3. **Data Storage**: Contact messages stored via abstracted storage interface
4. **Response Handling**: Structured JSON responses with error handling
5. **UI Updates**: React Query manages cache invalidation and optimistic updates

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling and validation
- **zod**: Runtime type validation
- **framer-motion**: Animation library

### UI Dependencies
- **@radix-ui/***: Headless UI primitives for accessibility
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Static type checking
- **drizzle-kit**: Database migration tool

## Deployment Strategy

The application is configured for production deployment with:

1. **Build Process**: 
   - Frontend: Vite builds optimized static assets
   - Backend: esbuild bundles server code for Node.js
   - Output: `dist/` directory with both client and server assets

2. **Environment Configuration**:
   - Development: Hot reloading with Vite middleware
   - Production: Static file serving with Express
   - Database: Environment-based connection via `DATABASE_URL`

3. **Scripts**:
   - `npm run dev`: Development server with hot reloading
   - `npm run build`: Production build
   - `npm start`: Production server
   - `npm run db:push`: Database schema synchronization

## Changelog

Changelog:
- June 30, 2025. Initial setup
- June 30, 2025. Converted to GitHub Pages compatible static site with Formspree contact form integration

## User Preferences

Preferred communication style: Simple, everyday language.