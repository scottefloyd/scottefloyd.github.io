#!/usr/bin/env node

import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { writeFileSync, mkdirSync, existsSync, rmSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log('🚀 Building for GitHub Pages...');

// Clean docs directory
if (existsSync('docs')) {
  rmSync('docs', { recursive: true, force: true });
}
mkdirSync('docs', { recursive: true });

try {
  // Build the client
  console.log('📦 Building client...');
  execSync('cd client && npx vite build --outDir ../docs --base ./ --emptyOutDir', { 
    stdio: 'inherit',
    cwd: __dirname 
  });

  // Create .nojekyll file for GitHub Pages
  writeFileSync(join(__dirname, 'docs', '.nojekyll'), '');
  
  // Create 404.html for SPA routing
  const indexContent = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="./vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Scott Floyd - UX/UI Designer</title>
    <meta name="description" content="Scott Floyd - UX/UI Designer with expertise in user experience design and development. View my portfolio of design work and get in touch.">
    <script type="module" crossorigin src="./assets/index.js"></script>
    <link rel="stylesheet" crossorigin href="./assets/index.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>`;

  writeFileSync(join(__dirname, 'docs', '404.html'), indexContent);

  console.log('✅ GitHub Pages build complete!');
  console.log('📁 Files generated in docs/ directory');
  console.log('🌐 Ready for GitHub Pages deployment');

} catch (error) {
  console.error('❌ Build failed:', error.message);
  process.exit(1);
}