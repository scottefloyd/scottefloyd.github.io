import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import { motion } from "framer-motion";

interface Testimonial {
  id: string;
  name: string;
  role: string;
  image: string;
  quote: string;
}

const testimonials: Testimonial[] = [
  {
    id: "sarah",
    name: "Sarah Johnson",
    role: "UX Instructor, DevMountain",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b2a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    quote: "Scott's background in QA automation brings a unique perspective to his UX design work. He thinks about edge cases and user flows in ways that make designs more robust and user-friendly."
  },
  {
    id: "maria",
    name: "Maria Rodriguez", 
    role: "UX Designer, Bootcamp Colleague",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b2a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    quote: "Working with Scott on our team project was fantastic. His attention to detail and methodical approach to problem-solving really elevated our final deliverable."
  },
  {
    id: "david",
    name: "David Chen",
    role: "Frontend Developer",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    quote: "Scott's technical background shines through in his design work. He creates prototypes that not only look great but are also technically feasible and well-thought-out."
  }
];

function TestimonialCard({ testimonial, index }: { testimonial: Testimonial; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      viewport={{ once: true }}
    >
      <Card className="bg-white p-8 rounded-2xl shadow-lg h-full">
        <CardContent className="p-0">
          <div className="flex items-center mb-4">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-current" />
              ))}
            </div>
          </div>
          <blockquote className="text-slate-600 mb-6 leading-relaxed">
            "{testimonial.quote}"
          </blockquote>
          <div className="flex items-center">
            <img 
              src={testimonial.image} 
              alt={testimonial.name} 
              className="w-12 h-12 rounded-full mr-4 object-cover"
            />
            <div>
              <div className="font-semibold text-primary">{testimonial.name}</div>
              <div className="text-slate-500 text-sm">{testimonial.role}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">What People Say</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Feedback from colleagues, instructors, and collaborators on my work and approach.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard 
              key={testimonial.id} 
              testimonial={testimonial} 
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
