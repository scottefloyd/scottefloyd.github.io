import { Linkedin, Github } from "lucide-react";

export function Footer() {
  const socialLinks = [
    { icon: <Linkedin className="w-5 h-5" />, href: "https://www.linkedin.com/in/scottefloyd/" },
    { icon: <Github className="w-5 h-5" />, href: "https://github.com/scottefloyd" }
  ];

  return (
    <footer className="bg-primary text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="text-2xl font-bold gradient-text mb-4">Scott Floyd</div>
          <p className="text-slate-300 mb-6">UX/UI Designer & QA Automation Developer</p>
          <div className="flex justify-center space-x-6 mb-8">
            {socialLinks.map((link, index) => (
              <a
                key={index}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-white transition-colors duration-300"
              >
                {link.icon}
              </a>
            ))}
          </div>
          <div className="border-t border-slate-700 pt-8">
            <p className="text-slate-400 text-sm">
              © 2024 Scott Floyd. All rights reserved. | Designed with ❤️ and lots of ☕
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
