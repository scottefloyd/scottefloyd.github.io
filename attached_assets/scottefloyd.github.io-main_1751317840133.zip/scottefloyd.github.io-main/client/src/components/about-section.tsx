import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { motion } from "framer-motion";

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">About Me</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            I'm a passionate UX/UI designer with a unique background in QA automation, bringing both creative vision and technical precision to every project.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="UX Designer Workspace with sketches and prototypes" 
              className="rounded-2xl shadow-2xl w-full"
            />
          </motion.div>

          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div>
              <h3 className="text-2xl font-semibold text-primary mb-4">My Journey</h3>
              <p className="text-slate-600 leading-relaxed mb-4">
                My transition from QA automation to UX design has given me a unique perspective on creating user experiences that are both beautiful and functional. I understand the importance of testing and validation in the design process.
              </p>
              <p className="text-slate-600 leading-relaxed">
                Through my bootcamp at DevMountain, I've developed strong skills in user research, prototyping, and visual design, always keeping the user at the center of every decision.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-4 bg-slate-50 rounded-xl">
                <div className="text-3xl font-bold text-accent mb-2">15+</div>
                <div className="text-slate-600">Projects Completed</div>
              </div>
              <div className="text-center p-4 bg-slate-50 rounded-xl">
                <div className="text-3xl font-bold text-accent mb-2">2+</div>
                <div className="text-slate-600">Years Experience</div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-200">
              <a href="/scott-floyd-resume.pdf" download="Scott-Floyd-Resume.pdf">
                <Button 
                  variant="outline" 
                  size="lg"
                  className="inline-flex items-center gap-3 px-8 py-4 text-base font-semibold hover:bg-accent hover:text-white transition-all duration-300 border-2 border-accent text-accent hover:shadow-lg"
                >
                  <Download className="w-5 h-5" />
                  Download Resume
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
