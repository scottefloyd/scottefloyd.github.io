import { Palette, Search, Code } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

interface Skill {
  name: string;
  level: number;
}

interface SkillCategory {
  title: string;
  icon: React.ReactNode;
  color: string;
  skills: Skill[];
}

const skillCategories: SkillCategory[] = [
  {
    title: "Design",
    icon: <Palette className="w-6 h-6" />,
    color: "bg-blue-100 text-blue-600",
    skills: [
      { name: "UI/UX Design", level: 4 },
      { name: "Prototyping", level: 5 },
      { name: "Visual Design", level: 4 }
    ]
  },
  {
    title: "Research", 
    icon: <Search className="w-6 h-6" />,
    color: "bg-purple-100 text-purple-600",
    skills: [
      { name: "User Research", level: 5 },
      { name: "Usability Testing", level: 4 },
      { name: "Task Analysis", level: 5 }
    ]
  },
  {
    title: "Technical",
    icon: <Code className="w-6 h-6" />,
    color: "bg-green-100 text-green-600",
    skills: [
      { name: "QA Automation", level: 5 },
      { name: "HTML/CSS", level: 4 },
      { name: "JavaScript", level: 3 }
    ]
  }
];

const tools = [
  "Figma", "Sketch", "Adobe XD", "InVision", "Miro", 
  "Selenium", "Jira", "Git"
];

function SkillBar({ skill }: { skill: Skill }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-600">{skill.name}</span>
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((dot) => (
          <div
            key={dot}
            className={`w-2 h-2 rounded-full ${
              dot <= skill.level ? "bg-current" : "bg-slate-300"
            }`}
          />
        ))}
      </div>
    </div>
  );
}

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">Skills & Tools</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            A comprehensive toolkit for creating exceptional user experiences from research to final implementation.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              className="text-center p-8 bg-slate-50 rounded-2xl"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto mb-6`}>
                {category.icon}
              </div>
              <h3 className="text-xl font-semibold text-primary mb-4">{category.title}</h3>
              <div className="space-y-3">
                {category.skills.map((skill) => (
                  <div key={skill.name} className={category.color.split(' ')[1]}>
                    <SkillBar skill={skill} />
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tools */}
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-semibold text-primary mb-8">Tools & Software</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {tools.map((tool) => (
              <Badge key={tool} variant="secondary" className="px-4 py-2 text-slate-700 font-medium">
                {tool}
              </Badge>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
