import { Button } from "@/components/ui/button";
import { ChevronDown, Linkedin, Github } from "lucide-react";
import { smoothScrollTo } from "@/lib/utils";
import { motion } from "framer-motion";

export function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 parallax-bg"
        style={{
          backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.7), rgba(15, 23, 42, 0.7)), url('https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')`
        }}
      />

      <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
        <motion.div 
          className="mb-8"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <img 
            src="https://scottefloyd.github.io/images/me2.png" 
            alt="Scott Floyd Professional Headshot" 
            className="w-32 h-32 rounded-full mx-auto mb-6 border-4 border-white shadow-2xl"
          />
        </motion.div>

        <motion.h1 
          className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Hello, I'm <span className="gradient-text">Scott Floyd</span>
        </motion.h1>

        <motion.p 
          className="text-xl md:text-2xl mb-4 font-light"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          UX/UI Designer & QA Automation Developer
        </motion.p>

        <motion.p 
          className="text-lg mb-8 max-w-2xl mx-auto leading-relaxed"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          Graduate of top UX Design and Development Bootcamps. Passionate about advocating for end-users and collaborating with development teams.
        </motion.p>

        <motion.div 
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <Button 
            size="lg" 
            onClick={() => smoothScrollTo("projects")}
            className="bg-accent hover:bg-blue-600 text-white px-8 py-4 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
          >
            View My Work
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => smoothScrollTo("contact")}
            className="border-2 border-white text-white bg-white/20 backdrop-blur-sm hover:bg-white hover:text-primary px-8 py-4 rounded-full font-semibold transition-all duration-300"
          >
            Get In Touch
          </Button>
        </motion.div>

        <motion.div 
          className="flex justify-center space-x-6"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
        >
          <a href="https://www.linkedin.com/in/scottefloyd/" target="_blank" rel="noopener noreferrer" className="text-white hover:text-accent transition-colors duration-300">
            <Linkedin className="w-6 h-6" />
          </a>
          <a href="https://github.com/scottefloyd" target="_blank" rel="noopener noreferrer" className="text-white hover:text-accent transition-colors duration-300">
            <Github className="w-6 h-6" />
          </a>
        </motion.div>
      </div>

      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white cursor-pointer"
        onClick={() => smoothScrollTo("about")}
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="w-8 h-8" />
      </motion.div>
    </section>
  );
}
