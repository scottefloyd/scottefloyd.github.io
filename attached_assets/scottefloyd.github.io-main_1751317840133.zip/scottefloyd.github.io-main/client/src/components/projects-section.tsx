import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  image: string;
  link: string;
  categoryColor: string;
}

const projects: Project[] = [
  {
    id: "rent-all",
    title: "Rent-All Case Study",
    description: "Design process for an app that enables people to make money by renting out their unused household items.",
    category: "UX Design",
    image: "https://scottefloyd.github.io/images/ra-cover.jpg",
    link: "https://scottefloyd.github.io/rent-all-case-study.html",
    categoryColor: "bg-blue-100 text-blue-600"
  },
  {
    id: "cyclist",
    title: "Cyclist Case Study", 
    description: "The design process from concept to high fidelity for a website to support community biking.",
    category: "UX Design",
    image: "https://scottefloyd.github.io/images/cyclist-preview.jpg",
    link: "https://scottefloyd.github.io/cyclist-case-study.html",
    categoryColor: "bg-blue-100 text-blue-600"
  },
  {
    id: "ann-arbor",
    title: "City of Ann Arbor Task Analysis",
    description: "A comprehensive task analysis conducted on a dated, overly technical city website.",
    category: "Usability",
    image: "https://scottefloyd.github.io/images/a2.png",
    link: "https://scottefloyd.github.io/assets/a2-task-analysis.pdf",
    categoryColor: "bg-green-100 text-green-600"
  },
  {
    id: "photobook",
    title: "Photobook Usability Report",
    description: "Comprehensive usability analysis of digital photobook design UI with actionable insights.",
    category: "User Research",
    image: "https://scottefloyd.github.io/images/photobook.jpeg",
    link: "https://scottefloyd.github.io/assets/usability-report-summary.pdf",
    categoryColor: "bg-purple-100 text-purple-600"
  },
  {
    id: "boogie-battle",
    title: "Boogie Battle Mobile App",
    description: "Final project for a front-end web development bootcamp showcasing mobile interaction design.",
    category: "Mobile App",
    image: "https://scottefloyd.github.io/images/boogie-preview.jpg",
    link: "https://scottefloyd.github.io/assets/boogie-battle-report.pdf",
    categoryColor: "bg-orange-100 text-orange-600"
  },
  {
    id: "extreme-sports",
    title: "Extreme Sports App Survey",
    description: "Comprehensive survey and analysis of an app concept for extreme sports competitions.",
    category: "User Research",
    image: "https://scottefloyd.github.io/images/kiter.jpg",
    link: "https://scottefloyd.github.io/assets/comp-app-survey.pdf",
    categoryColor: "bg-purple-100 text-purple-600"
  }
];

const categories = ["All Projects", "UX Design", "User Research", "Mobile App", "Usability"];

export function ProjectsSection() {
  const [activeFilter, setActiveFilter] = useState("All Projects");

  const filteredProjects = activeFilter === "All Projects" 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  return (
    <section id="projects" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">Featured Projects</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Explore my portfolio of user-centered design solutions, from mobile apps to web platforms.
          </p>
        </motion.div>

        {/* Project Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeFilter === category ? "default" : "outline"}
              onClick={() => setActiveFilter(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                activeFilter === category
                  ? "bg-accent text-white hover:bg-blue-600"
                  : "bg-white text-slate-600 border-slate-200 hover:bg-accent hover:text-white"
              }`}
            >
              {category}
            </Button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white rounded-2xl shadow-lg overflow-hidden card-hover cursor-pointer h-full">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={`${project.title} preview`} 
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <CardContent className="p-6 flex flex-col h-full">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className={`${project.categoryColor} font-semibold`}>
                      {project.category}
                    </Badge>
                    <ExternalLink className="w-4 h-4 text-slate-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-primary mb-3">{project.title}</h3>
                  <p className="text-slate-600 mb-4 leading-relaxed flex-grow">
                    {project.description}
                  </p>
                  <a 
                    href={project.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-accent hover:text-blue-600 font-semibold transition-colors duration-300 gap-2"
                  >
                    {project.category === "Mobile App" ? "View Report" : 
                     project.category === "Usability" || project.category === "User Research" ? "View Report" : 
                     "View Case Study"}
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
