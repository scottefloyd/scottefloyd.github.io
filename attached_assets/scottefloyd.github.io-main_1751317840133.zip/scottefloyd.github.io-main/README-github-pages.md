# GitHub Pages Deployment Guide

This portfolio website can be deployed to GitHub Pages using the static build configuration.

## Quick Setup

1. **Create a new repository on GitHub** and push this code to it.

2. **Enable GitHub Pages**:
   - Go to Settings > Pages in your repository
   - Select "GitHub Actions" as the source
   - The workflow will automatically build and deploy your site

3. **Update the contact form**:
   - Sign up for a free [Formspree](https://formspree.io) account
   - Create a new form and get your form ID
   - Replace `YOUR_FORM_ID` in `client/src/components/contact-section.tsx` with your actual form ID

## Manual Build (Optional)

To build the static site locally:

```bash
# Build static version
cd client && npx vite build --config ../vite.config.static.ts --outDir ../docs

# Preview locally
cd .. && npx vite preview --config vite.config.static.ts
```

## Configuration

The GitHub Actions workflow (`.github/workflows/deploy.yml`) automatically:
- Installs dependencies
- Builds the static site
- Deploys to GitHub Pages

## Contact Form Setup

The contact form uses Formspree for handling submissions without a backend:

1. Go to [formspree.io](https://formspree.io)
2. Create an account and new form
3. Copy your form endpoint ID
4. Update line 44 in `client/src/components/contact-section.tsx`:
   ```typescript
   const response = await fetch("https://formspree.io/f/YOUR_FORM_ID", {
   ```
   Replace `YOUR_FORM_ID` with your actual Formspree form ID.

## Repository Settings

Make sure your repository name matches your desired URL:
- For `username.github.io`: Repository name should be `username.github.io`
- For custom domain: Repository can have any name, configure custom domain in Pages settings

Your site will be available at:
- `https://username.github.io/repository-name` (if repository name is not username.github.io)
- `https://username.github.io` (if repository name is username.github.io)